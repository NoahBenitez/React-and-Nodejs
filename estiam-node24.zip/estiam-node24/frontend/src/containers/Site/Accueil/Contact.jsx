import React, { useState } from 'react';

function App() {
    // État pour stocker la liste des personnes
    const [people, setPeople] = useState([]);
    // État pour stocker les valeurs des champs du formulaire
    const [formData, setFormData] = useState({prenom: '', nom: '', livre: '', date_emprunt: '', date_retour: '', email: '', editId: ''});

    // Fonction pour vider la liste des personnes
    function clearList() {
        setPeople([]);
    }

    // Fonction pour supprimer une entrée de la liste
    function remove(id) {
        setPeople(people.filter(person => person.id !== id));
    }

    // Fonction pour modifier les informations d'un utilisateur
    function edit(id) {
        const personToEdit = people.find(person => person.id === id);
        setFormData({...personToEdit, editId: id});
    }

    // Fonction pour enregistrer les informations du formulaire (pour ajouter ou modifier)
    function save() {
        const {prenom, nom, livre, date_emprunt, date_retour, email, editId} = formData;

        // Vérifier si les champs sont vides
        if (prenom === "" || nom === "" || livre === "" || date_emprunt === "" || date_retour === "" || email === "") {
            alert("Veuillez remplir tous les champs.");
            return;
        }

        if (editId) {
            // Si editId existe, cela signifie qu'il s'agit d'une modification
            setPeople(people.map(person => person.id === editId ? {...formData} : person));
            // Réinitialiser l'editId
            setFormData({...formData, editId: ''});
        } else {
            // Sinon, c'est une nouvelle entrée
            const newPerson = {
                id: Date.now(), // Création d'un nouvel identifiant unique
                prenom,
                nom,
                livre,
                date_emprunt,
                date_retour,
                email
            };
            setPeople([...people, newPerson]);
        }

        // Réinitialisation des champs du formulaire
        setFormData({prenom: '', nom: '', livre: '', date_emprunt: '', date_retour: '', email: '', editId: ''});
    }

    return (
        <div>
            {/* Contenu */}
            <div className="container mt-5">
                <div className="row">
                    <div className="card col-md-3">
                        <div className="card-header text-center">INFOS PERSONNELLES</div>
                        <div className="card-body">
                            <div className="form-group">
                                <label className="label-control" htmlFor="">Prénom</label>
                                <input className="form-control" type="text" placeholder="Votre prénom ici" required value={formData.prenom} onChange={(e) => setFormData({...formData, prenom: e.target.value})} />
                            </div>
                            <div className="form-group">
                                <label className="label-control" htmlFor="">Nom</label>
                                <input className="form-control" type="text" placeholder="Votre nom ici" required value={formData.nom} onChange={(e) => setFormData({...formData, nom: e.target.value})} />
                            </div>
                            <div className="form-group">
                                <label className="label-control" htmlFor="">Livre</label>
                                <input className="form-control" type="text" placeholder="Nom du livre" required value={formData.livre} onChange={(e) => setFormData({...formData, livre: e.target.value})} />
                            </div>
                            <div className="form-group">
                                <label className="label-control" htmlFor="">Date d'emprunt</label>
                                <input className="form-control" type="date" required value={formData.date_emprunt} onChange={(e) => setFormData({...formData, date_emprunt: e.target.value})} />
                            </div>
                            <div className="form-group">
                                <label className="label-control" htmlFor="">Date de retour</label>
                                <input className="form-control" type="date" required value={formData.date_retour} onChange={(e) => setFormData({...formData, date_retour: e.target.value})} />
                            </div>
                            <div className="form-group">
                                <label className="label-control" htmlFor="">Email</label>
                                <input className="form-control" type="email" placeholder="Votre email ici" required value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} />
                            </div>
                            <div className="form-group">
                                <button className="btn btn-primary" onClick={save}>Enregistrer</button>
                            </div>
                        </div>
                    </div>
                    <div className="card col-md-9 text-center">
                        <div className="card-header">
                            LISTE DES PERSONNES
                            <button className="btn btn-sm btn-dark" onClick={clearList}>Vider</button>
                        </div>
                        <div className="card-body">
                            <table className="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Num</th>
                                        <th>Prénom</th>
                                        <th>Nom</th>
                                        <th>Livre</th>
                                        <th>Date d'emprunt</th>
                                        <th>Date de retour</th>
                                        <th>Email</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {people.map(person => (
                                        <tr key={person.id}>
                                            <td>{person.id}</td>
                                            <td>{person.prenom}</td>
                                            <td>{person.nom}</td>
                                            <td>{person.livre}</td>
                                            <td>{person.date_emprunt}</td>
                                            <td>{person.date_retour}</td>
                                            <td>{person.email}</td>
                                            <td>
                                                <button className="btn btn-danger btn-sm" onClick={() => remove(person.id)}>Supprimer</button>
                                                <button className="btn btn-warning btn-sm" onClick={() => edit(person.id)}>Modifier</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default App;
