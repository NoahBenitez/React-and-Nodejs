import Img from "../../../components/img"

function Accueil() {
  
    return (
        <div>
 
            <Img /> 
        </div>
  )
}
export default Accueil