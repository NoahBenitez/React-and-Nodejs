import React from 'react';

export default function Img() {
  const containerStyle = {
    position: 'relative',
    textAlign: 'center',
    color: 'white',
  };

  const textStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    fontSize: '24px',
    fontWeight: 'bold',
    textShadow: '2px 2px 4px rgba(0, 0, 0, 0.5)',
  };

  return (
    <div style={containerStyle}>
      <img src='/src/assets/images/livres.jpg' alt='Image de livres' />
      <div style={textStyle}>
        <p>Decouvrez notre Temple
             du Savoir concue dans l'unique but de divertir  
        </p>
      </div>
    </div>
  );
}
