const mongoose = require("mongoose")



const LivreSchema = new mongoose.Schema({
    _id : mongoose.Schema.Types.ObjectId,
    nom : String,
    auteur: String,
    pages: Number
})



const LivreModel = mongoose.model("livres", LivreSchema)
module.exports = LivreModel